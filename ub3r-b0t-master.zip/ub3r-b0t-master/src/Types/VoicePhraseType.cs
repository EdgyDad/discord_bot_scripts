﻿namespace UB3RB0T
{
    public enum VoicePhraseType
    {
        UserJoin,
        UserRejoin,
        UserLeave,
        BotJoin,
        BotLeave,
    }
}
