﻿namespace UB3RB0T
{
    public enum BotType
    {
        Irc,
        Discord,
    }
}
