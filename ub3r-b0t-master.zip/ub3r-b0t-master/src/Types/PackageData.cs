﻿namespace UB3RB0T
{
    public class PackageData
    {
        public string Id { get; set; }
        public string Nick { get; set; }
        public string Channel { get; set; }
        public string Server { get; set; }
        public string Tracking { get; set; }
        public BotType BotType { get; set; }
    }
}
