﻿namespace UB3RB0T
{
    public enum AudioUserState
    {
        SeenOnce,
        SeenMultiple,
    }
}
